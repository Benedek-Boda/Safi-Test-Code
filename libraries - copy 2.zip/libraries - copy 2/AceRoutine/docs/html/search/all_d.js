var searchData=
[
  ['updateelapsedmicros_106',['updateElapsedMicros',['../classace__routine_1_1CoroutineProfiler.html#a914fde78366e0572b9b307020e3729c9',1,'ace_routine::CoroutineProfiler::updateElapsedMicros()'],['../classace__routine_1_1LogBinProfilerTemplate.html#abc696834db7c1c9dcee2c9b070d0a13a',1,'ace_routine::LogBinProfilerTemplate::updateElapsedMicros()']]]
];
