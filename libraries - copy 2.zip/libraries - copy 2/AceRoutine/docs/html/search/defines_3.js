var searchData=
[
  ['fpstr_220',['FPSTR',['../compat_8h.html#aaa60649c7ffe7ed1fbe16dc20ed7e8c3',1,'compat.h']]]
];
