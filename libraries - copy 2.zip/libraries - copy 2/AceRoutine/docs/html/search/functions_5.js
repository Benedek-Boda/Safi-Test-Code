var searchData=
[
  ['micros_152',['micros',['../classace__routine_1_1ClockInterface.html#ab8963dc53edb04d3ab800eac7c3b358e',1,'ace_routine::ClockInterface']]],
  ['millis_153',['millis',['../classace__routine_1_1ClockInterface.html#aeb6701bd63ee8fb7dbb81efaf0ac02bf',1,'ace_routine::ClockInterface']]]
];
