var searchData=
[
  ['knametypecstring_183',['kNameTypeCString',['../classace__routine_1_1CoroutineTemplate.html#ac2c0bed6845b265a15d047f5fb9e1f2a',1,'ace_routine::CoroutineTemplate']]],
  ['knametypefstring_184',['kNameTypeFString',['../classace__routine_1_1CoroutineTemplate.html#af5edcad4909c75a7dfe85f5b59135d1b',1,'ace_routine::CoroutineTemplate']]],
  ['knumbins_185',['kNumBins',['../classace__routine_1_1LogBinProfilerTemplate.html#af25fa69ddc686411422f38a2e7a461ee',1,'ace_routine::LogBinProfilerTemplate']]],
  ['kstatusdelaying_186',['kStatusDelaying',['../classace__routine_1_1CoroutineTemplate.html#affeba86cf0732cd88588732cc29e3fb3',1,'ace_routine::CoroutineTemplate']]],
  ['kstatusending_187',['kStatusEnding',['../classace__routine_1_1CoroutineTemplate.html#a300f41394630bc6324b7749afbb8e583',1,'ace_routine::CoroutineTemplate']]],
  ['kstatusrunning_188',['kStatusRunning',['../classace__routine_1_1CoroutineTemplate.html#af35a3db36cc75dce8aa9196ff3d4068b',1,'ace_routine::CoroutineTemplate']]],
  ['kstatussuspended_189',['kStatusSuspended',['../classace__routine_1_1CoroutineTemplate.html#af9b629c958610313eb1c0dc2d63cf047',1,'ace_routine::CoroutineTemplate']]],
  ['kstatusterminated_190',['kStatusTerminated',['../classace__routine_1_1CoroutineTemplate.html#aee76b758eb2c683b1823f05433bc13ee',1,'ace_routine::CoroutineTemplate']]],
  ['kstatusyielding_191',['kStatusYielding',['../classace__routine_1_1CoroutineTemplate.html#a803df9549b871e9071eb48b5a896cea7',1,'ace_routine::CoroutineTemplate']]]
];
