var searchData=
[
  ['udiv1000_184',['udiv1000',['../arithmetic_8h.html#a239844f52c0a01e7fcd0075739035783',1,'ace_common']]],
  ['update_185',['update',['../classace__common_1_1GenericStats.html#a6a8d12163d4b1977c86bb3c1ce17c16f',1,'ace_common::GenericStats::update()'],['../classace__common_1_1TimingStats.html#a7e2074483d3bace1f9695c573dac811e',1,'ace_common::TimingStats::update()']]]
];
