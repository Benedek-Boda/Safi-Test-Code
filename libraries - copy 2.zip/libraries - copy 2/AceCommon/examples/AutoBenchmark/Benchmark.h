#ifndef ACE_COMMON_BENCHMARK_H
#define ACE_COMMON_BENCHMARK_H

extern void runBenchmarks();

#endif
